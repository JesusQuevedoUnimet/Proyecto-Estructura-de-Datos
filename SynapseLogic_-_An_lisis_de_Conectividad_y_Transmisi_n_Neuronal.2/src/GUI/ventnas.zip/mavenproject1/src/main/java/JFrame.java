/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author andre
 */
class JFrame {
    
}
import javax.swing.*;

public class PanelCSV extends JPanel {

    public PanelCSV() {
        add(new JLabel("Cargar CSV"));
        add(new JButton("Seleccionar archivo"));
    }
}
``